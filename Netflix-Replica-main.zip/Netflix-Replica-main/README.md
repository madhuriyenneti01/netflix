# Netflix-Replica
Netflix Replica
Hosting URL: https://anilkumarraju28.github.io/Netflix-Replica
